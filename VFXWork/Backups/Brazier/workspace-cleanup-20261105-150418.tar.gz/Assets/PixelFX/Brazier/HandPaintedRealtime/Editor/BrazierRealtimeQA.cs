using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;

namespace PixelFX.Brazier.HandPaintedRealtime.Editor
{
    // Editor-only inspection and camera capture. Does not drive runtime particles or shader time.
    public static class BrazierRealtimeQA
    {
        const string Root = BrazierRealtimeSetup.Root;
        const string Preview = BrazierRealtimeSetup.Preview;
        [Serializable] class StructureReport
        {
            public bool passed, noAttachedScripts, noFlipbook, noAnimator, noVfxLights, staticTexturesOnly;
            public string dataPath, scene, timestamp;
            public string[] componentTypes, dependencies;
            public int fullSystems, flameSystems, coreSystems, staticTextureCount;
        }
        [Serializable] class LiveReport
        {
            public bool passed, actualPlayMode, motionObserved, customClockAdvances, emissionZeroStops, emissionRestores;
            public string scene, timestamp, note;
            public int sparksBefore, sparksOff, sparksRestored, coreParticles, capturedFrames;
            public float clockBefore, clockAfter, motionDistance;
            public double elapsedSeconds;
        }
        static GameObject[] Roots()
        {
            BrazierRealtimeSetup.VerifyTarget();
            if (SceneManager.GetActiveScene().path != BrazierRealtimeSetup.ScenePath)
                throw new InvalidOperationException("Open the handpainted realtime showcase, not another scene.");
            return SceneManager.GetActiveScene().GetRootGameObjects().Where(x => x.name == BrazierRealtimeSetup.FullName || x.name == BrazierRealtimeSetup.FlameName).ToArray();
        }
        [MenuItem("Tools/PixelFX/Brazier Handpainted Realtime/Validate NO Flipbook or Scripts")]
        public static void Validate()
        {
            var roots=Roots();if(roots.Length!=2)throw new Exception("Expected both full and flame-only instances.");
            var deps=new HashSet<string>();
            foreach(var name in new[]{BrazierRealtimeSetup.FullName,BrazierRealtimeSetup.FlameName})
            {
                var path=Root+"/Prefabs/"+name+".prefab";
                var prefab=AssetDatabase.LoadAssetAtPath<GameObject>(path);
                if(!prefab)throw new Exception("Missing prefab: "+path);
                foreach(var target in new[]{prefab,roots.Single(x=>x.name==name)})
                {
                    var components=target.GetComponentsInChildren<Component>(true);
                    if(components.Any(c=>!c || !(c is Transform || c is ParticleSystem || c is ParticleSystemRenderer || c is SpriteRenderer)))
                        throw new Exception("Unexpected component / attached script / missing script: "+name);
                    var systems=target.GetComponentsInChildren<ParticleSystem>(true);
                    int expected=name==BrazierRealtimeSetup.FullName?18:17;
                    if(systems.Length!=expected || systems.Count(p=>p.name.StartsWith("Tongue_"))!=11)throw new Exception("System/core count mismatch: "+name);
                    foreach(var ps in systems)
                    {
                        var sheet=ps.textureSheetAnimation;var r=ps.GetComponent<ParticleSystemRenderer>();
                        if(sheet.enabled || sheet.numTilesX!=1 || sheet.numTilesY!=1)throw new Exception("Flipbook forbidden: "+ps.name);
                        if(ps.lights.enabled || ps.subEmitters.subEmittersCount!=0 || ps.main.stopAction==ParticleSystemStopAction.Callback)
                            throw new Exception("Unexpected light, callback or death successor absent from HD source: "+ps.name);
                        if(!r.enabled)continue;
                        if(!r.sharedMaterial || !r.sharedMaterial.mainTexture || r.sharedMaterial.shader.name!=BrazierRealtimeSetup.ShaderName
                            || ShaderUtil.ShaderHasError(r.sharedMaterial.shader) || !r.sharedMaterial.shader.isSupported
                            || r.alignment!=ParticleSystemRenderSpace.View || r.allowRoll)throw new Exception("Invalid realtime renderer: "+ps.name);
                        var streams=new List<ParticleSystemVertexStream>();r.GetActiveVertexStreams(streams);
                        if(!streams.Contains(ParticleSystemVertexStream.Custom1XYZW) || !streams.Contains(ParticleSystemVertexStream.UV2))
                            throw new Exception("Native custom data stream packing mismatch.");
                        if(ps.name.StartsWith("Tongue_") && (!ps.customData.enabled || ps.main.maxParticles!=1 || r.sharedMaterial.GetFloat("_MorphEnabled")!=1))
                            throw new Exception("Core must use one static texture plus native-clock contour shader.");
                    }
                    if(target.GetComponentsInChildren<SpriteRenderer>(true).Length!=(name==BrazierRealtimeSetup.FullName?2:0))throw new Exception("Prop split mismatch.");
                }
                foreach(var d in AssetDatabase.GetDependencies(path,true))
                {
                    deps.Add(d);
                    var extension=Path.GetExtension(d).ToLowerInvariant();
                    if(new[]{".cs",".json",".anim",".controller",".mp4",".gif",".playable"}.Contains(extension)
                        || (d.StartsWith("Assets/") && !d.StartsWith(Root+"/")))throw new Exception("External/runtime/movie dependency: "+d);
                }
            }
            var textures=AssetDatabase.FindAssets("t:Texture2D",new[]{Root+"/Textures"});
            if(textures.Length!=19)throw new Exception("Expected nineteen independent static PNGs, not a frame sequence.");
            foreach(var guid in textures)
            {
                string path=AssetDatabase.GUIDToAssetPath(guid);var ti=(TextureImporter)AssetImporter.GetAtPath(path);
                bool data=path.Contains("Noise");
                if(ti.filterMode!=FilterMode.Bilinear || ti.mipmapEnabled || ti.textureCompression!=TextureImporterCompression.Uncompressed || ti.sRGBTexture==data)
                    throw new Exception("Texture import mismatch: "+path);
                if(path.Contains("Prop") && ti.spriteImportMode!=SpriteImportMode.Single)throw new Exception("Props must be static single sprites.");
            }
            Directory.CreateDirectory(Preview);
            var full=roots.Single(x=>x.name==BrazierRealtimeSetup.FullName);
            var report=new StructureReport{passed=true,noAttachedScripts=true,noFlipbook=true,noAnimator=true,noVfxLights=true,staticTexturesOnly=true,
                dataPath=Application.dataPath,scene=SceneManager.GetActiveScene().path,timestamp=DateTime.Now.ToString("O"),
                componentTypes=full.GetComponentsInChildren<Component>(true).Select(x=>x.GetType().Name).Distinct().OrderBy(x=>x).ToArray(),
                dependencies=deps.OrderBy(x=>x).ToArray(),fullSystems=18,flameSystems=17,coreSystems=11,staticTextureCount=textures.Length};
            File.WriteAllText(Preview+"/Structure.json",JsonUtility.ToJson(report,true));
            Debug.Log("[Brazier Realtime] PASS: prefab + instances, 19 static textures, 11 realtime cores, NO flipbook, attached scripts, animation, recipe or old-version dependencies.");
        }
        static void Simulate(float time)
        {
            if(Application.isPlaying)throw new Exception("Deterministic sampling is Edit Mode only.");
            foreach(var root in Roots()) {var ps=root.GetComponent<ParticleSystem>();ps.Simulate(time,true,true,false);ps.Pause(true);}
        }
        static Camera CaptureCamera()
        {
            var go=new GameObject("TEMP Editor-only realtime QA camera"){hideFlags=HideFlags.HideAndDontSave};
            var camera=go.AddComponent<Camera>();camera.CopyFrom(Camera.main);camera.enabled=false;
            camera.GetUniversalAdditionalCameraData().renderPostProcessing=false;
            return camera;
        }
        static void SoloCamera(Camera camera,GameObject root)
        {
            camera.orthographic=true;camera.orthographicSize=5;camera.clearFlags=CameraClearFlags.SolidColor;
            camera.backgroundColor=new Color(21/255f,24/255f,32/255f,1);
            camera.transform.SetPositionAndRotation(root.transform.position+new Vector3(0,215f/128,-12),Quaternion.identity);
        }
        static void Render(Camera camera,string name,int width=768,int height=960)
        {
            var path=Preview+"/"+name+".png";Directory.CreateDirectory(Path.GetDirectoryName(path));
            var rt=RenderTexture.GetTemporary(width,height,24,RenderTextureFormat.ARGB32,RenderTextureReadWrite.sRGB);
            var previous=RenderTexture.active;Texture2D texture=null;
            try
            {
                camera.aspect=(float)width/height;
                RenderPipeline.SubmitRenderRequest(camera,new UniversalRenderPipeline.SingleCameraRequest{destination=rt});
                RenderTexture.active=rt;texture=new Texture2D(width,height,TextureFormat.RGBA32,false);
                texture.ReadPixels(new Rect(0,0,width,height),0,0);texture.Apply();File.WriteAllBytes(path,texture.EncodeToPNG());
            }
            finally {RenderTexture.active=previous;RenderTexture.ReleaseTemporary(rt);if(texture)UnityEngine.Object.DestroyImmediate(texture);}
        }
        [MenuItem("Tools/PixelFX/Brazier Handpainted Realtime/Capture Layers and Views")]
        public static void Capture()
        {
            var roots=Roots();Validate();Simulate(.8f);var full=roots.Single(x=>x.name==BrazierRealtimeSetup.FullName);
            var renderers=roots.SelectMany(x=>x.GetComponentsInChildren<Renderer>(true)).ToArray();var enabled=renderers.Select(r=>r.enabled).ToArray();
            var camera=CaptureCamera();
            try
            {
                camera.transform.SetPositionAndRotation(Camera.main.transform.position,Camera.main.transform.rotation);
                Render(camera,"Combined",1280,720);SoloCamera(camera,full);
                for(int i=0;i<renderers.Length;i++)renderers[i].enabled=enabled[i] && renderers[i].transform.IsChildOf(full.transform);
                Render(camera,"SourcePhase_0.8",1024,1280);
                camera.backgroundColor=new Color(.72f,.74f,.77f,1);Render(camera,"LightBackground");
                SoloCamera(camera,full);
                foreach(string layer in new[]{"01_Core","02_Detached","03_Smoke","04_Glow","05_Prop"})
                {
                    var group=full.transform.Cast<Transform>().Single(t=>t.name.StartsWith(layer));
                    for(int i=0;i<renderers.Length;i++)renderers[i].enabled=enabled[i] && renderers[i].transform.IsChildOf(group);
                    Render(camera,layer);
                }
                for(int i=0;i<renderers.Length;i++)renderers[i].enabled=enabled[i] && renderers[i].transform.IsChildOf(full.transform);
                var center=full.transform.position+new Vector3(0,1.5f,0);
                camera.transform.position=center+Quaternion.Euler(35,30,0)*new Vector3(0,0,-12);camera.transform.LookAt(center);Render(camera,"Oblique35deg");
                SoloCamera(camera,full);Simulate(1.8f);Render(camera,"SourcePhase_1.8");
            }
            finally {for(int i=0;i<renderers.Length;i++)if(renderers[i])renderers[i].enabled=enabled[i];UnityEngine.Object.DestroyImmediate(camera.gameObject);Simulate(.8f);}
        }
        [MenuItem("Tools/PixelFX/Brazier Handpainted Realtime/Capture Deterministic Native Motion")]
        public static void CaptureMotion()
        {
            if(Application.isPlaying)throw new Exception("Use live capture in Play Mode.");
            var roots=Roots();var full=roots.Single(x=>x.name==BrazierRealtimeSetup.FullName);
            var other=roots.Single(x=>x!=full);bool active=other.activeSelf;var camera=CaptureCamera();
            try
            {
                other.SetActive(false);SoloCamera(camera,full);
                for(int frame=0;frame<80;frame++){Simulate(4+frame/20f);Render(camera,"Motion/Frame_"+frame.ToString("000"),512,640);}
            }
            finally {other.SetActive(active);UnityEngine.Object.DestroyImmediate(camera.gameObject);Simulate(.8f);}
            Debug.Log("[Brazier Realtime] Captured 80 native simulation samples; output is QA only, not a runtime texture sequence.");
        }
        static float Clock(ParticleSystem ps)
        {
            var data=new List<Vector4>();ps.GetCustomParticleData(data,ParticleSystemCustomData.Custom1);
            return data.Count>0?data[0].x:-1;
        }
        static Action stopLive;
        [MenuItem("Tools/PixelFX/Brazier Handpainted Realtime/Verify ACTUAL Play Mode and Capture")]
        public static void VerifyLivePlayback()
        {
            var roots=Roots();if(!Application.isPlaying)throw new Exception("Enter Play Mode first; this does not simulate or schedule particles.");
            if(stopLive!=null)throw new Exception("Live QA already running.");
            var full=roots.Single(x=>x.name==BrazierRealtimeSetup.FullName);var other=roots.Single(x=>x!=full);
            var systems=full.GetComponentsInChildren<ParticleSystem>();
            var sparks=systems.Single(p=>p.name.StartsWith("Sparks"));var core=systems.First(p=>p.name.StartsWith("Tongue_"));
            var particles=new ParticleSystem.Particle[128];int count=sparks.GetParticles(particles);
            if(count==0)throw new Exception("Wait for startup before checking live motion.");
            uint seed=particles[0].randomSeed;Vector3 before=particles[0].position;
            var oldRate=sparks.emission.rateOverTime;bool otherActive=other.activeSelf;
            var camera=CaptureCamera();SoloCamera(camera,full);other.SetActive(false);
            var report=new LiveReport{actualPlayMode=true,sparksBefore=count,clockBefore=Clock(core),scene=SceneManager.GetActiveScene().path,timestamp=DateTime.Now.ToString("O"),
                note="Actual engine playback. Editor callback only observes/captures, temporarily toggles Emission, then restores it. No Simulate, SetParticles, Emit, or material-time writes."};
            double started=EditorApplication.timeSinceStartup,stageAt=started,nextCapture=started;int stage=0,frame=0;
            EditorApplication.CallbackFunction tick=null;
            stopLive=()=>{EditorApplication.update-=tick;if(sparks){var e=sparks.emission;e.rateOverTime=oldRate;}if(other)other.SetActive(otherActive);if(camera)UnityEngine.Object.DestroyImmediate(camera.gameObject);stopLive=null;};
            tick=()=>
            {
                try
                {
                    if(!Application.isPlaying || !sparks){stopLive();return;}
                    double now=EditorApplication.timeSinceStartup,elapsed=now-stageAt;
                    if(stage==0)
                    {
                        if(now>=nextCapture && frame<64){Render(camera,"LiveMotion/Frame_"+frame.ToString("000"),512,640);frame++;nextCapture=now+1.0/15;}
                        if(elapsed>.20 && !report.customClockAdvances)
                        {
                            report.clockAfter=Clock(core);report.customClockAdvances=report.clockAfter>=0 && Mathf.Abs(report.clockAfter-report.clockBefore)>.02f;
                            int n=sparks.GetParticles(particles);
                            for(int i=0;i<n;i++)if(particles[i].randomSeed==seed){report.motionDistance=Vector3.Distance(before,particles[i].position);report.motionObserved=report.motionDistance>.005f;}
                        }
                        if(frame<64)return;
                        var emission=sparks.emission;emission.rateOverTime=0;stage=1;stageAt=now;
                    }
                    else if(stage==1 && elapsed>2.7)
                    {
                        report.sparksOff=sparks.particleCount;report.emissionZeroStops=report.sparksOff==0;
                        var emission=sparks.emission;emission.rateOverTime=oldRate;stage=2;stageAt=now;
                    }
                    else if(stage==2 && elapsed>1.25)
                    {
                        report.sparksRestored=sparks.particleCount;report.emissionRestores=report.sparksRestored>0;
                        report.coreParticles=systems.Where(p=>p.name.StartsWith("Tongue_")).Sum(p=>p.particleCount);
                        report.capturedFrames=frame;report.elapsedSeconds=now-started;
                        report.passed=report.motionObserved && report.customClockAdvances && report.emissionZeroStops && report.emissionRestores && report.coreParticles==11;
                        stopLive();File.WriteAllText(Preview+"/LivePlayback.json",JsonUtility.ToJson(report,true));Validate();
                        Debug.Log("[Brazier Realtime] Actual Play Mode motion / native custom clock / emission off-expire-restore: "+report.passed);
                    }
                }
                catch(Exception ex){stopLive?.Invoke();Debug.LogException(ex);}
            };
            EditorApplication.update+=tick;
            Debug.Log("[Brazier Realtime] Live QA started: observing and rendering only; then native Emission off / expiry / restore.");
        }
    }
}
