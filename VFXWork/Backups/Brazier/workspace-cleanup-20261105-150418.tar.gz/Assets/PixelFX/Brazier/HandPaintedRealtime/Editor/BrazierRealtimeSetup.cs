using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;

namespace PixelFX.Brazier.HandPaintedRealtime.Editor
{
    // Editor-only authoring. Never attached to a prefab or used by runtime playback.
    public static class BrazierRealtimeSetup
    {
        public const string Root = "Assets/PixelFX/Brazier/HandPaintedRealtime";
        public const string ScenePath = Root + "/Scenes/BrazierHandPaintedShowcase.unity";
        public const string FullName = "BrazierHandPaintedRealtime";
        public const string FlameName = "BrazierHandPaintedFlameRealtime";
        public const string Preview = "VFXWork/Previews/Brazier/HandPaintedRealtime";
        public const float PPU = 128;
        const string Staging = "VFXWork/Exports/Brazier/HandPaintedRealtime";
        public const string ShaderName = "PixelFX/Brazier Handpainted Realtime Dissolve URP";

        #pragma warning disable 0649
        [Serializable] class Recipe
        {
            public int version, sourceVersion, seed, framesPerTexture;
            public bool textureAnimation, atlas;
            public string source, sourceSha256;
            public Tongue[] tongues;
        }
        [Serializable] class Tongue
        {
            public float x, h, w, lean, id, sourceX, sourceY;
            public int textureWidth, textureHeight, rootX, rootY, sortingOrder;
            public string file;
            public bool back;
        }
        #pragma warning restore 0649

        public static void VerifyTarget()
        {
            if (Application.dataPath != "/Users/user/Desktop/VFXDemo/VFXDemo/Assets"
                || Application.productName != "VFXDemo"
                || !(GraphicsSettings.currentRenderPipeline is UniversalRenderPipelineAsset))
                throw new InvalidOperationException("Not the authorized VFXDemo URP editor.");
        }

        [MenuItem("Tools/PixelFX/Brazier Handpainted Realtime/Build NEW Non-Flipbook Version")]
        public static void Build() { BuildInternal(false); }

        // Explicit rebuild for this generated version only. Future manual Inspector edits must be
        // saved as a Variant or backed up first; the default Build refuses to overwrite a prefab.
        public static void RebuildGeneratedVersion() { BuildInternal(true); }

        static void BuildInternal(bool rebuild)
        {
            VerifyTarget();
            if (EditorApplication.isPlayingOrWillChangePlaymode) throw new InvalidOperationException("Exit Play Mode before building.");
            for (int i=0;i<SceneManager.sceneCount;i++) if (SceneManager.GetSceneAt(i).isDirty)
                throw new InvalidOperationException("Scene has unsaved edits; not replacing it.");
            if (!rebuild && File.Exists(Root+"/Prefabs/"+FullName+".prefab"))
                throw new InvalidOperationException("This version already exists. Preserve manual edits; create a new version/Variant.");
            var recipe=JsonUtility.FromJson<Recipe>(File.ReadAllText(Staging+"/manifest.json"));
            string hash;
            using (var sha=SHA256.Create()) hash=BitConverter.ToString(sha.ComputeHash(File.ReadAllBytes(recipe.source))).Replace("-","").ToLowerInvariant();
            if (hash!=recipe.sourceSha256 || recipe.sourceVersion!=3 || recipe.seed!=8 || recipe.tongues.Length!=11
                || recipe.textureAnimation || recipe.atlas || recipe.framesPerTexture!=1)
                throw new InvalidOperationException("Approved source/hash or static-element export contract mismatch.");
            foreach (var d in new[]{"Textures","Materials","Prefabs","Scenes"}) Directory.CreateDirectory(Root+"/"+d);
            ImportArt();
            var shader=Shader.Find(ShaderName);
            if (!shader || !shader.isSupported || ShaderUtil.ShaderHasError(shader)) throw new InvalidOperationException("Realtime shader is not supported or has errors.");

            // The previous scene was verified clean. Only our newly created showcase is modified.
            var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
            var fullPrefab=MakePrefab(recipe,true);var flamePrefab=MakePrefab(recipe,false);
            var full=(GameObject)PrefabUtility.InstantiatePrefab(fullPrefab,scene);
            var flame=(GameObject)PrefabUtility.InstantiatePrefab(flamePrefab,scene);
            full.transform.position=new Vector3(-2.25f,0,0);flame.transform.position=new Vector3(2.25f,0,0);
            var cameraObject=new GameObject("Main Camera");var camera=cameraObject.AddComponent<Camera>();cameraObject.tag="MainCamera";
            camera.orthographic=true;camera.orthographicSize=4.9f;camera.nearClipPlane=.1f;camera.farClipPlane=40;
            camera.transform.position=new Vector3(0,1.6f,-12);camera.transform.rotation=Quaternion.identity;
            camera.clearFlags=CameraClearFlags.SolidColor;camera.backgroundColor=new Color(21/255f,24/255f,32/255f,1);
            camera.allowHDR=false;camera.allowMSAA=false;camera.GetUniversalAdditionalCameraData().renderPostProcessing=false;
            EditorSceneManager.SaveScene(scene,ScenePath);AssetDatabase.SaveAssets();
            BrazierRealtimeQA.Validate();
            Selection.activeGameObject=full;EditorApplication.ExecuteMenuItem("Window/General/Game");
            Debug.Log("[Brazier Realtime] Built two script-free prefabs: 19 static PNGs, NO Texture Sheet Animation, NO flipbook/Animator/video.");
        }

        static void ImportArt()
        {
            foreach (string file in Directory.GetFiles(Staging,"*.png").OrderBy(x=>x))
            {
                string name=Path.GetFileName(file),path=Root+"/Textures/"+name;var bytes=File.ReadAllBytes(file);
                if (!File.Exists(path) || !File.ReadAllBytes(path).SequenceEqual(bytes)) File.WriteAllBytes(path,bytes);
                AssetDatabase.ImportAsset(path,ImportAssetOptions.ForceSynchronousImport);
                var importer=(TextureImporter)AssetImporter.GetAtPath(path);
                bool data=name.Contains("Noise"),sprite=name.StartsWith("Prop");
                importer.textureType=sprite?TextureImporterType.Sprite:TextureImporterType.Default;
                importer.sRGBTexture=!data;importer.alphaIsTransparency=!data;importer.mipmapEnabled=false;
                importer.filterMode=FilterMode.Bilinear;importer.wrapMode=data?TextureWrapMode.Repeat:TextureWrapMode.Clamp;
                importer.textureCompression=TextureImporterCompression.Uncompressed;importer.maxTextureSize=1024;
                importer.npotScale=TextureImporterNPOTScale.None;
                if (sprite)
                {
                    importer.spriteImportMode=SpriteImportMode.Single;importer.spritePixelsPerUnit=PPU;
                    var settings=new TextureImporterSettings();importer.ReadTextureSettings(settings);
                    settings.spriteAlignment=(int)SpriteAlignment.Custom;settings.spritePivot=new Vector2(.5f,1-87f/512);
                    settings.spriteMeshType=SpriteMeshType.FullRect;importer.SetTextureSettings(settings);
                }
                importer.SaveAndReimport();
            }
        }

        static Material Mat(string name,string texture,int order,bool flame=false,bool additive=false)
        {
            string path=Root+"/Materials/"+name+".mat";var material=AssetDatabase.LoadAssetAtPath<Material>(path);
            if (!material) { material=new Material(Shader.Find(ShaderName)){name=name};AssetDatabase.CreateAsset(material,path); }
            material.mainTexture=AssetDatabase.LoadAssetAtPath<Texture2D>(Root+"/Textures/"+texture);
            material.SetTexture("_Dissolve",AssetDatabase.LoadAssetAtPath<Texture2D>(Root+"/Textures/DissolveNoise.png"));
            material.SetTexture("_DistortTex",AssetDatabase.LoadAssetAtPath<Texture2D>(Root+"/Textures/DistortionNoise.png"));
            material.SetColor("_TintColor",Color.white);material.SetFloat("_Intensity",1);
            material.SetFloat("_DstBlend",(float)(additive?BlendMode.One:BlendMode.OneMinusSrcAlpha));
            material.SetFloat("_UseParticleData",flame?1:0);material.SetFloat("_MorphEnabled",flame?1:0);
            material.SetFloat("_EnableDistortion",flame?1:0);material.SetFloat("_EnableDissolve",flame?1:0);
            material.SetFloat("_HandDrawnEdge",flame?1:0);material.SetFloat("_PigmentGrain",flame?1:0);
            material.SetFloat("_LoopDuration",4);material.SetFloat("_DistortStrength",33);
            material.SetFloat("_DissolveAmount",0);material.SetFloat("_BaseDissolve",.14f);material.SetFloat("_TipDissolve",.40f);
            material.SetFloat("_Soft_Dissolve",.28f);material.SetFloat("_InkWidth",1.9f);material.SetFloat("_InkRoughness",.65f);
            var ink=Linear("#a13419",.75f);material.SetColor("_InkColor",ink);
            material.renderQueue=3000+order;EditorUtility.SetDirty(material);return material;
        }

        static Color Linear(string hex,float alpha=1)
        {
            ColorUtility.TryParseHtmlString(hex,out var color);color=color.linear;color.a=alpha;return color;
        }
        static Transform Group(Transform parent,string name)
        {
            var go=new GameObject(name);go.transform.SetParent(parent,false);return go.transform;
        }
        static ParticleSystem Emitter(Transform parent,string name,Material material,int order,uint seed)
        {
            var go=new GameObject(name);if(parent)go.transform.SetParent(parent,false);
            var ps=go.AddComponent<ParticleSystem>();ps.Stop(false,ParticleSystemStopBehavior.StopEmittingAndClear);
            ps.useAutoRandomSeed=false;ps.randomSeed=seed;
            var m=ps.main;m.duration=4;m.loop=true;m.prewarm=true;m.playOnAwake=true;
            m.startLifetime=1;m.startSpeed=0;m.startSize=1;m.startColor=Color.white;m.maxParticles=128;
            m.simulationSpace=ParticleSystemSimulationSpace.Local;m.scalingMode=ParticleSystemScalingMode.Hierarchy;
            m.cullingMode=ParticleSystemCullingMode.AlwaysSimulate;m.stopAction=ParticleSystemStopAction.None;
            var e=ps.emission;e.rateOverTime=0;var shape=ps.shape;shape.enabled=false;
            var sheet=ps.textureSheetAnimation;sheet.enabled=false;sheet.numTilesX=1;sheet.numTilesY=1;
            var lights=ps.lights;lights.enabled=false;
            var r=ps.GetComponent<ParticleSystemRenderer>();r.sharedMaterial=material;r.renderMode=ParticleSystemRenderMode.Billboard;
            r.alignment=ParticleSystemRenderSpace.View;r.allowRoll=false;r.sortingOrder=order;r.sortMode=ParticleSystemSortMode.OldestInFront;
            r.shadowCastingMode=ShadowCastingMode.Off;r.receiveShadows=false;r.lightProbeUsage=LightProbeUsage.Off;
            r.reflectionProbeUsage=ReflectionProbeUsage.Off;r.minParticleSize=0;r.maxParticleSize=1;
            r.SetActiveVertexStreams(new List<ParticleSystemVertexStream>{ParticleSystemVertexStream.Position,ParticleSystemVertexStream.Color,
                ParticleSystemVertexStream.UV,ParticleSystemVertexStream.UV2,ParticleSystemVertexStream.Custom1XYZW});
            NativeData(ps,4,false,false);return ps;
        }

        static void NativeData(ParticleSystem ps,float seconds,bool dissolve,bool randomPhase)
        {
            var custom=ps.customData;custom.enabled=true;custom.SetMode(ParticleSystemCustomData.Custom1,ParticleSystemCustomDataMode.Vector);
            custom.SetVectorComponentCount(ParticleSystemCustomData.Custom1,4);
            custom.SetVector(ParticleSystemCustomData.Custom1,0,new ParticleSystem.MinMaxCurve(seconds,AnimationCurve.Linear(0,0,1,1)));
            custom.SetVector(ParticleSystemCustomData.Custom1,1,dissolve?new ParticleSystem.MinMaxCurve(1,AnimationCurve.Linear(0,0,1,1)):new ParticleSystem.MinMaxCurve(0));
            custom.SetVector(ParticleSystemCustomData.Custom1,2,new ParticleSystem.MinMaxCurve(1));
            custom.SetVector(ParticleSystemCustomData.Custom1,3,randomPhase?new ParticleSystem.MinMaxCurve(0,4):new ParticleSystem.MinMaxCurve(0));
        }
        static void Rate(ParticleSystem ps,float rate){var e=ps.emission;e.rateOverTime=rate;}
        static void Life(ParticleSystem ps,float a,float b){var m=ps.main;m.startLifetime=new ParticleSystem.MinMaxCurve(a,b);}
        static void Rect(ParticleSystem ps,float x,float y)
        {
            var m=ps.main;m.startSize3D=true;m.startSizeX=x;m.startSizeY=y;m.startSizeZ=1;
        }
        static void Box(ParticleSystem ps,float x,float y)
        {
            var s=ps.shape;s.enabled=true;s.shapeType=ParticleSystemShapeType.Box;s.scale=new Vector3(x,y,.01f);
        }
        static void Noise(ParticleSystem ps,float x,float y,float frequency)
        {
            var n=ps.noise;n.enabled=true;n.separateAxes=true;n.strengthX=x;n.strengthY=y;n.strengthZ=0;
            n.frequency=frequency;n.scrollSpeed=.3f;n.damping=true;n.quality=ParticleSystemNoiseQuality.High;n.octaveCount=2;
        }
        static void Fade(ParticleSystem ps,float alpha,bool sine=false)
        {
            var g=new Gradient();g.SetKeys(new[]{new GradientColorKey(Color.white,0),new GradientColorKey(Color.white,1)},
                sine?new[]{new GradientAlphaKey(0,0),new GradientAlphaKey(.71f*alpha,.25f),new GradientAlphaKey(alpha,.5f),new GradientAlphaKey(.71f*alpha,.75f),new GradientAlphaKey(0,1)}
                :new[]{new GradientAlphaKey(0,0),new GradientAlphaKey(alpha,.08f),new GradientAlphaKey(alpha,.5f),new GradientAlphaKey(0,1)});
            var c=ps.colorOverLifetime;c.enabled=true;c.color=g;
        }
        static AnimationCurve SparkY(float amplitude,float referenceLife)
        {
            var keys=new Keyframe[25];for(int i=0;i<keys.Length;i++){
                float u=i/24f,t=u*referenceLife,e=Mathf.Exp(-1.15f*t);
                keys[i]=new Keyframe(u,(1.15f*amplitude*e+90)/PPU,-1.15f*1.15f*amplitude*e*referenceLife/PPU,-1.15f*1.15f*amplitude*e*referenceLife/PPU);
            }return new AnimationCurve(keys);
        }
        static ParticleSystem.MinMaxCurve Pair(float a,float b)
        {
            return new ParticleSystem.MinMaxCurve(1,AnimationCurve.Constant(0,1,a),AnimationCurve.Constant(0,1,b));
        }
        static ParticleSystem Core(Transform parent,Tongue q,int index)
        {
            var mat=Mat("Tongue_"+(index+1).ToString("00"),q.file,q.sortingOrder,true);
            mat.SetVector("_TongueShape",new Vector4(q.h,q.w,q.lean,q.id));
            mat.SetVector("_TextureRect",new Vector4(q.textureWidth,q.textureHeight,q.rootX,q.rootY));
            mat.SetVector("_SourceOrigin",new Vector4(q.sourceX,q.sourceY,0,0));
            var ps=Emitter(parent,"Tongue_"+(index+1).ToString("00")+" - GPU contour, ONE static texture",mat,q.sortingOrder,(uint)(8100+index));
            ps.transform.localPosition=new Vector3(q.x/PPU,-5/PPU,0);
            var m=ps.main;m.prewarm=false;m.startLifetime=4;m.maxParticles=1;
            Rect(ps,q.textureWidth/PPU,q.textureHeight/PPU);
            var e=ps.emission;e.SetBursts(new[]{new ParticleSystem.Burst(0,1)});
            ps.GetComponent<ParticleSystemRenderer>().pivot=new Vector3(.5f-q.rootX/(float)q.textureWidth,q.rootY/(float)q.textureHeight-.5f,0);
            return ps;
        }

        static void Glow(Transform parent,string name,Material material,Vector2 position,Vector2 size,float alpha,uint seed)
        {
            var ps=Emitter(parent,name,material,-5,seed);ps.transform.localPosition=new Vector3(position.x,position.y,0);
            var m=ps.main;m.prewarm=false;m.startLifetime=4;m.maxParticles=1;m.startColor=Linear("#ff9b43",alpha);
            Rect(ps,size.x,size.y);var e=ps.emission;e.SetBursts(new[]{new ParticleSystem.Burst(0,1)});
            var g=new Gradient();var a=new GradientAlphaKey[8];for(int i=0;i<8;i++){
                float u=i/7f;a[i]=new GradientAlphaKey(.9f+.08f*Mathf.Sin(u*Mathf.PI*6)+.04f*Mathf.Sin(u*Mathf.PI*14),u);
            }g.SetKeys(new[]{new GradientColorKey(Color.white,0),new GradientColorKey(Color.white,1)},a);
            var c=ps.colorOverLifetime;c.enabled=true;c.color=g;
        }

        static GameObject MakePrefab(Recipe recipe,bool prop)
        {
            var rootPS=Emitter(null,prop?FullName:FlameName,null,0,8);var root=rootPS.gameObject;
            var e=rootPS.emission;e.enabled=false;var main=rootPS.main;main.prewarm=false;main.maxParticles=1;
            rootPS.GetComponent<ParticleSystemRenderer>().enabled=false;
            var cores=Group(root.transform,"01_Core tongues - realtime contour and dissolve");
            var secondary=Group(root.transform,"02_Detached licks and sparks");
            var smokeGroup=Group(root.transform,"03_Smoke - native motion");
            var glowGroup=Group(root.transform,"04_Glow - additive particles");
            for(int i=0;i<recipe.tongues.Length;i++)Core(cores,recipe.tongues[i],i);

            var lickMat=Mat("DetachedLicks","DetachedLick.png",30,true);
            lickMat.SetVector("_TextureRect",new Vector4(128,256,64,235));lickMat.SetVector("_TongueShape",new Vector4(150,28,10,25));
            lickMat.SetVector("_SourceOrigin",new Vector4(512,600,0,0));lickMat.SetFloat("_TipDissolve",.20f);
            var licks=Emitter(secondary,"Detached licks - Emission 3 per second",lickMat,30,8201);
            licks.transform.localPosition=new Vector3(0,310/PPU,0);Box(licks,172/PPU,210/PPU);Rate(licks,3);Life(licks,.68f,1.18f);
            Rect(licks,.32f,.64f);var lm=licks.main;lm.startSizeX=new ParticleSystem.MinMaxCurve(.22f,.45f);lm.startSizeY=new ParticleSystem.MinMaxCurve(.44f,.90f);
            licks.GetComponent<ParticleSystemRenderer>().pivot=new Vector3(0,235f/256-.5f,0);
            var lv=licks.velocityOverLifetime;lv.enabled=true;lv.space=ParticleSystemSimulationSpace.Local;
            // Unity's vector velocity module requires matching curve modes on X/Y/Z.
            lv.x=Pair(-28/PPU,28/PPU);lv.y=Pair(110/PPU,110/PPU);lv.z=Pair(0,0);
            var keys=new Keyframe[17];for(int i=0;i<17;i++){float u=i/16f;float tangent=Mathf.PI*Mathf.Cos(u*Mathf.PI);keys[i]=new Keyframe(u,Mathf.Sin(u*Mathf.PI),tangent,tangent);}
            var ls=licks.sizeOverLifetime;ls.enabled=true;ls.size=new ParticleSystem.MinMaxCurve(1,new AnimationCurve(keys));
            NativeData(licks,1,true,true);

            var smoke=Emitter(smokeGroup,"Smoke plume - Emission 4 per second",Mat("Smoke","Smoke.png",0),0,8301);
            smoke.transform.localPosition=new Vector3(0,245/PPU,0);Box(smoke,110/PPU,12/PPU);Rate(smoke,4);Life(smoke,1.6f,2.8f);
            Rect(smoke,36.4f/PPU,53.2f/PPU);var sm=smoke.main;sm.startColor=Linear("#695b62",.11f);
            var sv=smoke.velocityOverLifetime;sv.enabled=true;sv.space=ParticleSystemSimulationSpace.Local;
            sv.x=Pair(-17/PPU,17/PPU);sv.y=Pair(100/PPU,132/PPU);sv.z=Pair(0,0);
            var ss=smoke.sizeOverLifetime;ss.enabled=true;ss.size=new ParticleSystem.MinMaxCurve(1,AnimationCurve.Linear(0,1,1,45f/14));
            Noise(smoke,14/PPU,3/PPU,.7f);Fade(smoke,1,true);

            var sparks=Emitter(secondary,"Sparks - Emission 8.5 per second",Mat("Sparks","Spark.png",50),50,8401);
            sparks.transform.localPosition=new Vector3(0,45/PPU,0);Box(sparks,200/PPU,8/PPU);Rate(sparks,8.5f);Life(sparks,.85f,2.35f);
            var spm=sparks.main;spm.startSize=new ParticleSystem.MinMaxCurve(.055f,.10f);
            var spv=sparks.velocityOverLifetime;spv.enabled=true;spv.space=ParticleSystemSimulationSpace.Local;
            spv.x=Pair(-35/PPU,35/PPU);spv.y=new ParticleSystem.MinMaxCurve(1,SparkY(240,1.6f),SparkY(430,1.6f));spv.z=Pair(0,0);
            Noise(sparks,9/PPU,0,1);
            var renderer=sparks.GetComponent<ParticleSystemRenderer>();renderer.renderMode=ParticleSystemRenderMode.Stretch;
            renderer.cameraVelocityScale=0;renderer.velocityScale=.012f;renderer.lengthScale=2;renderer.freeformStretching=true;renderer.rotateWithStretchDirection=true;
            var gradient=new Gradient();gradient.SetKeys(new[]{new GradientColorKey(Linear("#fff2ad"),0),new GradientColorKey(Linear("#ffc65b"),.5f),new GradientColorKey(Linear("#e77237"),1)},
                new[]{new GradientAlphaKey(0,0),new GradientAlphaKey(.95f,.06f),new GradientAlphaKey(.95f,.45f),new GradientAlphaKey(0,1)});
            var spc=sparks.colorOverLifetime;spc.enabled=true;spc.color=gradient;

            var glow=Mat("Glow","SoftGlow.png",-5,false,true);
            Glow(glowGroup,"Broad warm wash",glow,new Vector2(0,135/PPU),new Vector2(610/PPU,728/PPU),.0195f,8501);
            Glow(glowGroup,"Hot base glow",glow,new Vector2(0,30/PPU),new Vector2(410/PPU,286/PPU),.021f,8502);
            if(prop)
            {
                Glow(glowGroup,"Low reflected warm wash",glow,new Vector2(0,-298/PPU),new Vector2(470/PPU,78/PPU),.021f,8503);
                var holder=Group(root.transform,"05_Prop - ordinary SpriteRenderers");
                for(int i=0;i<2;i++){
                    var name=i==0?"PropBack":"PropFront";var sr=Group(holder,name).gameObject.AddComponent<SpriteRenderer>();
                    sr.sprite=AssetDatabase.LoadAssetAtPath<Sprite>(Root+"/Textures/"+name+".png");
                    sr.sharedMaterial=Mat(name,name+".png",i==0?2:40);sr.sortingOrder=i==0?2:40;
                }
            }
            var prefab=PrefabUtility.SaveAsPrefabAsset(root,Root+"/Prefabs/"+root.name+".prefab");
            UnityEngine.Object.DestroyImmediate(root);return prefab;
        }
    }
}
