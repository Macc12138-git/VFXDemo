# Brazier · 高清手绘 / 实时扭曲溶解 / 非序列帧

本文资源路径相对于 `HandPaintedRealtime/` 版本根目录（本文件的上一级）。

本版本按作者“将该特效导入 Unity，不要以帧动画体现”的明确指令独立创建。
原版 Brazier 和 InspectorParticles 保留，不是本版本的运行依赖。

## 使用

- 打开 `Scenes/BrazierHandPaintedShowcase.unity`，点击 Play。
  左侧为带火盆的完整效果，右侧为可接入已有模型的纯火焰。
- `Prefabs/BrazierHandPaintedRealtime.prefab`：完整效果，18 个原生 ParticleSystem、2 个普通 SpriteRenderer。
- `Prefabs/BrazierHandPaintedFlameRealtime.prefab`：纯火焰，17 个原生 ParticleSystem。
  根节点放在模型的火口；本版本的锚点就是火口，不是支架底部。128 源像素 = 1 Unity 单位。
- 根 ParticleSystem 不发射、Renderer 关闭，提供 Unity 标准 Play/Restart 入口。
  所有可见粒子采用原生 View Billboard，火星为 Stretched Billboard，Allow Roll 关闭。

## 不是帧动画

只有 **19 张独立静态 PNG**：11 根手绘火舌、1 根脱落火舌、2 张道具、光晕、烟、火星、2 张噪声场。
没有图集、图片序列、视频、Animator、Timeline；所有 Texture Sheet Animation 都关闭且为 1×1。
火舌不是只移动静态卡片：Shader 实时计算高度、摆动、弯曲和宽度，反向映射静态手绘笔触；
再做根部约束的 UV 扭曲、上部更强的噪声溶解、导数干笔边缘。

Shader 是对附件 `EffectDissolveDistort.shader` 的扭曲/溶解/粗糙边缘思路做的 URP 适配和扩展，
加入了已选 pixelfx 原稿的火舌解析形变；不是未经修改直接使用附件。附件本身未改动。

所有效果节点组件仅为 Transform、ParticleSystem、ParticleSystemRenderer、SpriteRenderer。
无 MonoBehaviour/缺失脚本、外部 Update、SetParticles/Emit 调度、隐藏控制器、运行时 JSON 或 JS。
Editor 文件夹中的静态制作/验收工具不挂载到任何预制体，且不进入 Player 构建。
光晕是独立加法粒子，无 Light，也不启用 Particle System Lights。

## 在 Inspector 中调整

| 分组 | 主要控制 |
| --- | --- |
| `01_Core tongues...` | 每根 1 个粒子、4 秒循环、Burst 1。材质 `_TongueShape` 为高/宽/倾斜/相位身份；Main Size 改整体尺寸 |
| 核心材质 | `_DistortStrength` 扭曲像素数、`_DissolveAmount` 额外溶解、`_BaseDissolve` 根部阈值、`_TipDissolve` 火尖侵蚀、`_Soft_Dissolve` 柔边、`_InkWidth/_InkRoughness` 干笔感 |
| `02_Detached licks...` | 原生 Emission 3/s、寿命 .68–1.18s、Shape 出生域、Velocity 上升、Size 正弦包络、Custom1.y 随年龄溶解 |
| `02_.../Sparks...` | 原生 Emission 8.5/s、寿命 .85–2.35s、指数衰减速度曲线、Noise、Color 冷却、Renderer 拉伸 |
| `03_Smoke...` | 原生 Emission 4/s、寿命 1.6–2.8s、Velocity、Noise、Size 增长、Color 淡入淡出 |
| `04_Glow...` | Main Start Color 的 Alpha/尺寸、Color over Lifetime 的呼吸。与普通颜色层分开加法混合 |
| `05_Prop...` | 两个普通 SpriteRenderer；火盆、煤炭和支架静态手绘 |

核心 Renderer 的 Vertex Streams 固定为 Position、Color、UV、UV2（填充）、Custom1XYZW。
原生 Custom Data 中 Custom1.x 是粒子年龄秒数（核心 0→4），y 为附加溶解，z 为扭曲强度倍率，w 为随机相位。
这些值由 ParticleSystem 自动推进，Shader 不依赖编辑器工具写入时间。
要改变核心循环时长，同时修改 Main Duration/Start Lifetime、Custom1.x 的终值和材质 `_LoopDuration`。
Velocity over Lifetime 的 X/Y/Z 使用相同的 Two Curves 模式；不要混用不同模式导致速度失效。

## 已验证与差异

验证目标：Unity 6000.3.19f1 / URP 17.3.0 / Linear / VFXDemo。
2026-11-05 编译无错误或警告；两个保存的预制体和展示场景实例均通过组件、静态贴图、材质及依赖检查。
已对比同尺度原稿、核心、次级粒子、烟、光、道具、组合、浅背景与 35° 斜视角。
真实 Play Mode 中：11 个核心粒子持续循环；Custom1.x 从 .020 推进到 .346；
火星正常运动，Emission 关闭并等待旧粒子耗尽后 **14 → 0**，恢复后 **11**。
64 张实时播放观察截图仅用于生成验收 GIF，全部在 Assets 外，**不是效果运行资源**。

项目根目录 `VFXWork/Previews/Brazier/HandPaintedRealtime/` 保存 Structure.json、LivePlayback.json、Comparison.png、
LayersAndOblique.png 和 BrazierHandPaintedRealtime-Live.gif；浏览器副本在 `Tools/PixelFX/output/unity-preview/brazier-handpainted-realtime/`。

保留的近似：原生 RNG/Noise 与原稿解析随机轨迹不逐粒子相同；静态颜料纹理跟随实时形变，
不独立重绘每条内层笔触；煤炭/金属反光静态；Linear Alpha/Additive 与 Canvas 合成不逐像素一致。
它是 2D 手绘 Billboard，不是体积火焰，斜视角下火盆平面和粒子朝向会有差异。
本 HD 原稿没有“死亡转烟”后继事件，因此不凭旧版本额外添加子发射器。
尚未做移动端/真机性能测量，不把编辑器验证视为设备性能保证。

## 来源与重建

选定源码：`Tools/PixelFX/src/hd/brazier-handpainted.js`，version 3、seed 8、1024×1280、4s/30fps 原稿预览。
SHA256：`a1b7bfcedb5713fd0aa9b78943d776e194bd1ebb3ecd50ba7811591338c98231`。
静态导出器：`Tools/PixelFX/tools/export-hd-brazier-realtime.mjs`，直接复用该原稿 helper，未读取预览帧。
中间合同：`VFXWork/Exports/Brazier/HandPaintedRealtime/manifest.json`。

菜单 `Tools > PixelFX > Brazier Handpainted Realtime` 提供结构检查、分层截图和真实播放验收。
默认 Build 拒绝覆盖已有版本。`RebuildGeneratedVersion()` 会覆盖**本版本生成参数**，
手工调参后请先创建 Prefab Variant/备份；它不是运行时功能。

布局来源：pixelfx / Sprite Fusion fire，MIT License，Copyright (c) 2026 Hugo Duprez。
