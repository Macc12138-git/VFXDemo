# Brazier 特效资源索引

本案例族统一以 `Assets/PixelFX/Brazier/` 为资源根目录，每个版本内部按资源类型分类，
使用说明位于各版本的 `Docs/README.md`。本次仅整理目录与工具路径，不重建作品或修改参数。

| 版本目录 | 实现 / 状态 |
| --- | --- |
| `NoiseRealtime/` | 静态噪声 + 实时 Shader + 原生粒子；当前打开的展示场景所属版本 |
| `HandPaintedRealtime/` | 静态手绘素材 + 实时轮廓/溶解 Shader + 原生粒子 |
| `InspectorParticles/` | 早期纯原生模块及单粒子图集版本，保留手工调整 |
| `AnimatedParticles/` | 历史源码调度桥接版本，不作为当前原生无脚本路线模板 |
| `Particles/` | 历史原生重组及朝向桥接版本 |
| `Flipbook/` | 最早的整幅序列帧对照版，由原根目录资源归档而来 |

所有现有 prefab、材质、贴图、Shader、脚本与场景的 GUID 均保留；
历史 `Scenes/` 保留作对照，不删除、不合并、不重建。后续新特效默认复用指定场景，
不能把历史 Build 菜单视为新效果的默认建场景方式。

## Assets 外的制作资料（路径相对于工程根目录）

- `VFXWork/Previews/Brazier/<Version>/`：Unity 截图、动态录制和验证报告。
- `VFXWork/Exports/Brazier/<Version>/`：静态中间资源与导出合同。
- `Tools/PixelFX/src/`：pixelfx 源码与共享库，保持工具原有模块结构。
- `Tools/PixelFX/output/`：创作输出及供浏览器画廊使用的预览副本。

历史报告内的原始时间、路径和测量值保持原样，不因目录整理改写成新的验证结果。
两版高清效果的渲染批次、合批和目标设备性能仍待测；目录整理不构成性能验收。

许可证：[LICENSE.txt](LICENSE.txt)。
