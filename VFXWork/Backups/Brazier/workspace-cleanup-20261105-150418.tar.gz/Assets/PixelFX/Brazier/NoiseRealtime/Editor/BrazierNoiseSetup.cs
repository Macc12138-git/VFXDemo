using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;

namespace PixelFX.Brazier.NoiseRealtime.Editor
{
    // Editor-only generator. No component is attached and no source recipe is read at runtime.
    public static class BrazierNoiseSetup
    {
        public const string Root="Assets/PixelFX/Brazier/NoiseRealtime";
        public const string ScenePath=Root+"/Scenes/BrazierNoiseShowcase.unity";
        public const string FullName="BrazierNoiseRealtime",FlameName="BrazierNoiseFlameRealtime";
        public const string Preview="VFXWork/Previews/Brazier/NoiseRealtime";
        public const string FlameShader="PixelFX/Brazier Noise Flame URP",ParticleShader="PixelFX/Brazier Noise Static Particle URP";
        const string Staging="VFXWork/Exports/Brazier/NoiseRealtime";
        public const float PPU=128,Flow=1.45f,CoreLifetime=8/Flow;
        #pragma warning disable 0649
        [Serializable] class Recipe{public int sourceVersion,seed,framesPerTexture;public bool textureAnimation,atlas;public string source,sourceSha256,shader,shaderSha256,secondary,secondarySha256;public Art[] textures;}
        [Serializable] class Art{public string file,sha256;}
        #pragma warning restore 0649
        public static void VerifyTarget()
        {
            string root=Path.GetFullPath(Path.Combine(Application.dataPath,"..")).Replace('\\','/');
            if(Application.productName!="VFXDemo" || !File.Exists(root+"/Tools/PixelFX/src/hd/noise-brazier.js")
                || !(GraphicsSettings.currentRenderPipeline is UniversalRenderPipelineAsset))throw new Exception("Expected the authorized VFXDemo URP project.");
        }
        static string Hash(string path){using(var sha=SHA256.Create())return BitConverter.ToString(sha.ComputeHash(File.ReadAllBytes(path))).Replace("-","").ToLowerInvariant();}
        [MenuItem("Tools/PixelFX/Brazier Noise Realtime/Build NEW Static Texture Version")]
        public static void Build()
        {
            VerifyTarget();if(EditorApplication.isPlayingOrWillChangePlaymode)throw new Exception("Exit Play Mode first.");
            for(int i=0;i<SceneManager.sceneCount;i++)if(SceneManager.GetSceneAt(i).isDirty)throw new Exception("Unsaved scene edits: not replacing the scene.");
            if(File.Exists(Root+"/Prefabs/"+FullName+".prefab"))throw new Exception("Version already exists. Preserve hand edits; use a new version/Variant.");
            var recipe=JsonUtility.FromJson<Recipe>(File.ReadAllText(Staging+"/manifest.json"));
            if(recipe.sourceVersion!=4||recipe.seed!=8||recipe.framesPerTexture!=1||recipe.textureAnimation||recipe.atlas
                ||Hash(recipe.source)!=recipe.sourceSha256||Hash(recipe.shader)!=recipe.shaderSha256||Hash(recipe.secondary)!=recipe.secondarySha256)
                throw new Exception("Approved static-source contract/hash mismatch.");
            foreach(var art in recipe.textures)if(Hash(Staging+"/"+art.file)!=art.sha256)throw new Exception("Static art hash mismatch: "+art.file);
            foreach(string d in new[]{"Textures","Materials","Prefabs","Scenes"})Directory.CreateDirectory(Root+"/"+d);
            ImportArt(recipe);
            foreach(string name in new[]{FlameShader,ParticleShader}){var s=Shader.Find(name);if(!s||!s.isSupported||ShaderUtil.ShaderHasError(s))throw new Exception("Shader error: "+name);}
            var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
            var full=(GameObject)PrefabUtility.InstantiatePrefab(MakePrefab(true),scene);
            var flame=(GameObject)PrefabUtility.InstantiatePrefab(MakePrefab(false),scene);
            full.transform.position=new Vector3(-2.3f,0,0);flame.transform.position=new Vector3(2.3f,0,0);
            var cameraGO=new GameObject("Main Camera");cameraGO.tag="MainCamera";var camera=cameraGO.AddComponent<Camera>();
            camera.orthographic=true;camera.orthographicSize=4.9f;camera.transform.position=new Vector3(0,1.68f,-12);
            camera.nearClipPlane=.1f;camera.farClipPlane=40;camera.clearFlags=CameraClearFlags.SolidColor;
            camera.backgroundColor=new Color(21/255f,24/255f,32/255f);camera.allowHDR=false;camera.allowMSAA=false;
            camera.GetUniversalAdditionalCameraData().renderPostProcessing=false;
            EditorSceneManager.SaveScene(scene,ScenePath);AssetDatabase.SaveAssets();BrazierNoiseQA.Validate();
            Selection.activeGameObject=full;EditorApplication.ExecuteMenuItem("Window/General/Game");
            Debug.Log("[Brazier Noise] Built NEW script-free version: 6 static images, realtime noise flame, native sparks/embers/smoke/glow. No flipbook.");
        }
        static void ImportArt(Recipe recipe)
        {
            foreach(var art in recipe.textures)
            {
                string path=Root+"/Textures/"+art.file;byte[] bytes=File.ReadAllBytes(Staging+"/"+art.file);
                if(!File.Exists(path)||!File.ReadAllBytes(path).SequenceEqual(bytes))File.WriteAllBytes(path,bytes);
                AssetDatabase.ImportAsset(path,ImportAssetOptions.ForceSynchronousImport);
                var ti=(TextureImporter)AssetImporter.GetAtPath(path);bool noise=art.file=="FlowNoise.png",prop=art.file.StartsWith("Prop");
                ti.textureType=prop?TextureImporterType.Sprite:TextureImporterType.Default;ti.sRGBTexture=!noise;
                ti.alphaIsTransparency=!noise;ti.mipmapEnabled=false;ti.filterMode=FilterMode.Bilinear;
                ti.wrapMode=noise?TextureWrapMode.Mirror:TextureWrapMode.Clamp;ti.npotScale=TextureImporterNPOTScale.None;
                ti.textureCompression=TextureImporterCompression.Uncompressed;ti.maxTextureSize=1024;
                if(prop){ti.spriteImportMode=SpriteImportMode.Single;ti.spritePixelsPerUnit=PPU;var settings=new TextureImporterSettings();ti.ReadTextureSettings(settings);
                    settings.spriteAlignment=(int)SpriteAlignment.Custom;settings.spritePivot=new Vector2(.5f,1-87f/512);settings.spriteMeshType=SpriteMeshType.FullRect;ti.SetTextureSettings(settings);}
                ti.SaveAndReimport();
            }
        }
        static Material Material(string name,string file,int order,bool additive=false,bool core=false)
        {
            var mat=new Material(Shader.Find(core?FlameShader:ParticleShader)){name=name};
            mat.mainTexture=AssetDatabase.LoadAssetAtPath<Texture2D>(Root+"/Textures/"+file);mat.renderQueue=3000+order;
            if(core){mat.SetFloat("_Flow",Flow);mat.SetFloat("_Stretch",2.7f);mat.SetFloat("_Scale",1.7f);mat.SetFloat("_Distortion",1.15f);
                mat.SetFloat("_Dissolve",.13f);mat.SetFloat("_Softness",.065f);mat.SetFloat("_Core",.8f);mat.SetFloat("_Steps",.15f);}
            else{mat.SetColor("_TintColor",Color.white);mat.SetFloat("_DstBlend",(float)(additive?BlendMode.One:BlendMode.OneMinusSrcAlpha));}
            AssetDatabase.CreateAsset(mat,Root+"/Materials/"+name+".mat");return mat;
        }
        static Transform Group(Transform root,string name){var go=new GameObject(name);go.transform.SetParent(root,false);return go.transform;}
        static ParticleSystem Emitter(Transform parent,string name,Material mat,int order,uint seed)
        {
            var go=new GameObject(name);if(parent)go.transform.SetParent(parent,false);var ps=go.AddComponent<ParticleSystem>();
            ps.Stop(false,ParticleSystemStopBehavior.StopEmittingAndClear);ps.useAutoRandomSeed=false;ps.randomSeed=seed;
            var m=ps.main;m.duration=8;m.loop=true;m.prewarm=true;m.startSpeed=0;m.startLifetime=1;m.startSize=1;
            m.maxParticles=128;m.playOnAwake=true;m.simulationSpeed=Flow;m.simulationSpace=ParticleSystemSimulationSpace.Local;
            m.scalingMode=ParticleSystemScalingMode.Hierarchy;m.cullingMode=ParticleSystemCullingMode.AlwaysSimulate;
            var e=ps.emission;e.rateOverTime=0;var s=ps.shape;s.enabled=false;var ts=ps.textureSheetAnimation;ts.enabled=false;ts.numTilesX=1;ts.numTilesY=1;
            var r=ps.GetComponent<ParticleSystemRenderer>();r.sharedMaterial=mat;r.sortingOrder=order;r.renderMode=ParticleSystemRenderMode.Billboard;
            r.alignment=ParticleSystemRenderSpace.View;r.allowRoll=false;r.sortMode=ParticleSystemSortMode.OldestInFront;
            r.shadowCastingMode=ShadowCastingMode.Off;r.receiveShadows=false;r.lightProbeUsage=LightProbeUsage.Off;r.reflectionProbeUsage=ReflectionProbeUsage.Off;
            r.minParticleSize=0;r.maxParticleSize=1;return ps;
        }
        // Native ParticleSystem converts its gamma-authored vertex colors for the active color space.
        // Do not pre-linearize them a second time (especially visible on gray smoke).
        public static Color ColorHex(string hex,float alpha=1){ColorUtility.TryParseHtmlString(hex,out var c);c.a=alpha;return c;}
        static void Rect(ParticleSystem ps,float x,float y){var m=ps.main;m.startSize3D=true;m.startSizeX=x;m.startSizeY=y;m.startSizeZ=1;}
        static void Box(ParticleSystem ps,float x,float y){var s=ps.shape;s.enabled=true;s.shapeType=ParticleSystemShapeType.Box;s.scale=new Vector3(x,y,.01f);}
        static void RateLife(ParticleSystem ps,float rate,float min,float max){var e=ps.emission;e.rateOverTime=rate;var m=ps.main;m.startLifetime=new ParticleSystem.MinMaxCurve(min,max);}
        static ParticleSystem.MinMaxCurve Pair(float min,float max){return new ParticleSystem.MinMaxCurve(1,AnimationCurve.Constant(0,1,min),AnimationCurve.Constant(0,1,max));}
        static AnimationCurve Decay(float velocity,float drag,float tail,float life)
        {
            var keys=new Keyframe[25];for(int i=0;i<25;i++){float u=i/24f,e=Mathf.Exp(-drag*u*life),value=(velocity*e+tail)/PPU,tangent=-drag*life*velocity*e/PPU;keys[i]=new Keyframe(u,value,tangent,tangent);}return new AnimationCurve(keys);
        }
        static void NativeNoise(ParticleSystem ps,float x,float y,float frequency)
        {
            var n=ps.noise;n.enabled=true;n.separateAxes=true;n.strengthX=x;n.strengthY=y;n.strengthZ=0;n.frequency=frequency;n.scrollSpeed=.35f;
            n.damping=true;n.quality=ParticleSystemNoiseQuality.High;n.octaveCount=2;
        }
        static void Gradient(ParticleSystem ps,GradientColorKey[] colors,GradientAlphaKey[] alpha)
        {
            var g=new Gradient();g.SetKeys(colors,alpha);var c=ps.colorOverLifetime;c.enabled=true;c.color=g;
        }
        static ParticleSystem Core(Transform root,Material mat)
        {
            var ps=Emitter(root,"Core - realtime noise UV warp and erosion",mat,10,8);var m=ps.main;m.simulationSpeed=1;
            m.duration=CoreLifetime;m.startLifetime=CoreLifetime;m.prewarm=false;m.maxParticles=1;
            Rect(ps,485/PPU,624/PPU);var e=ps.emission;e.SetBursts(new[]{new ParticleSystem.Burst(0,1)});
            var r=ps.GetComponent<ParticleSystemRenderer>();r.pivot=new Vector3(.5f-242f/485,617f/624-.5f,0);
            r.SetActiveVertexStreams(new List<ParticleSystemVertexStream>{ParticleSystemVertexStream.Position,ParticleSystemVertexStream.Color,
                ParticleSystemVertexStream.UV,ParticleSystemVertexStream.UV2,ParticleSystemVertexStream.Custom1XYZW});
            var data=ps.customData;data.enabled=true;data.SetMode(ParticleSystemCustomData.Custom1,ParticleSystemCustomDataMode.Vector);
            data.SetVectorComponentCount(ParticleSystemCustomData.Custom1,4);data.SetVector(ParticleSystemCustomData.Custom1,0,new ParticleSystem.MinMaxCurve(CoreLifetime,AnimationCurve.Linear(0,0,1,1)));
            for(int i=1;i<4;i++)data.SetVector(ParticleSystemCustomData.Custom1,i,new ParticleSystem.MinMaxCurve(0));return ps;
        }
        static void Spark(Transform root,Material mat,bool ember)
        {
            var ps=Emitter(root,ember?"Embers - slow fluttering native particles":"Sparks - directional native streaks",mat,30,ember?8402u:8401u);
            ps.transform.localPosition=new Vector3(0,119/PPU,0);Box(ps,204/PPU,140/PPU);
            RateLife(ps,ember?2:6,ember?1.9f:.9f,ember?3.05f:2.15f);var m=ps.main;
            if(ember){Rect(ps,4.2f/.86f/PPU,4.2f/.09f/PPU);m.startSizeX=new ParticleSystem.MinMaxCurve(3.4f/.86f/PPU,5.4f/.86f/PPU);m.startSizeY=new ParticleSystem.MinMaxCurve(3.4f/.09f/PPU,5.4f/.09f/PPU);m.startRotation=new ParticleSystem.MinMaxCurve(-Mathf.PI,Mathf.PI);}
            else{m.startSize=new ParticleSystem.MinMaxCurve(.25f,.32f);var r=ps.GetComponent<ParticleSystemRenderer>();r.renderMode=ParticleSystemRenderMode.Stretch;r.lengthScale=.65f;r.velocityScale=.004f;r.cameraVelocityScale=0;}
            var v=ps.velocityOverLifetime;v.enabled=true;v.space=ParticleSystemSimulationSpace.Local;
            float refLife=ember?2.475f:1.525f,drag=ember?.9f:1.35f,x=ember?56:112;
            v.x=new ParticleSystem.MinMaxCurve(1,Decay(-x,drag,4.08f,refLife),Decay(x,drag,4.08f,refLife));
            v.y=new ParticleSystem.MinMaxCurve(1,Decay(ember?140:225,drag,ember?65:94,refLife),Decay(ember?140:350,drag,ember?65:94,refLife));v.z=Pair(0,0);
            NativeNoise(ps,ember?.11f:.065f,.02f,.65f);
            Gradient(ps,new[]{new GradientColorKey(ColorHex("#fff1b2"),0),new GradientColorKey(ColorHex("#ffc258"),.5f),new GradientColorKey(ColorHex("#e86c2e"),1)},
                new[]{new GradientAlphaKey(0,0),new GradientAlphaKey(.92f,.07f),new GradientAlphaKey(.92f,.4f),new GradientAlphaKey(0,1)});
            var size=ps.sizeOverLifetime;size.enabled=true;size.size=ember?new ParticleSystem.MinMaxCurve(1,new AnimationCurve(new Keyframe(0,.65f),new Keyframe(.3f,1),new Keyframe(.65f,.75f),new Keyframe(1,.45f))):new ParticleSystem.MinMaxCurve(1,AnimationCurve.Linear(0,1,1,.4f));
        }
        static void Smoke(Transform root,Material mat)
        {
            var ps=Emitter(root,"Smoke - rising expanding static puffs",mat,0,8501);ps.transform.localPosition=new Vector3(0,270/PPU,0);
            Box(ps,92/PPU,70/PPU);RateLife(ps,3.5f,2.3f,3);var m=ps.main;m.startSize=new ParticleSystem.MinMaxCurve(74/PPU,100/PPU);
            m.startRotation=new ParticleSystem.MinMaxCurve(-Mathf.PI,Mathf.PI);
            var v=ps.velocityOverLifetime;v.enabled=true;v.space=ParticleSystemSimulationSpace.Local;v.x=Pair(-4.96f/PPU,15.04f/PPU);v.y=Pair(95/PPU,120/PPU);v.z=Pair(0,0);
            var force=ps.forceOverLifetime;force.enabled=true;force.space=ParticleSystemSimulationSpace.Local;force.y=9/PPU;
            NativeNoise(ps,.13f,.04f,.7f);var rotation=ps.rotationOverLifetime;rotation.enabled=true;rotation.z=new ParticleSystem.MinMaxCurve(0,.2f);
            var size=ps.sizeOverLifetime;size.enabled=true;size.separateAxes=true;
            size.x=new ParticleSystem.MinMaxCurve(1,new AnimationCurve(new Keyframe(0,.9f),new Keyframe(.5f,2),new Keyframe(1,3.48f)));
            size.y=new ParticleSystem.MinMaxCurve(1,AnimationCurve.Linear(0,1.15f,1,2.76f));size.z=1;
            Gradient(ps,new[]{new GradientColorKey(ColorHex("#9d8370"),0),new GradientColorKey(ColorHex("#817d80"),.4f),new GradientColorKey(ColorHex("#747985"),1)},
                new[]{new GradientAlphaKey(0,0),new GradientAlphaKey(.18f,.2f),new GradientAlphaKey(.18f,.5f),new GradientAlphaKey(0,1)});
        }
        static void Glow(Transform root,Material mat,string name,Vector2 position,Vector2 size,Color color,bool breathe)
        {
            var ps=Emitter(root,name,mat,-5,8601);ps.transform.localPosition=position;Rect(ps,size.x,size.y);var m=ps.main;
            // Canvas adds in 8-bit RGB; lower alpha in Unity linear additive space to match its subtle halo.
            color.a*=.2f;
            m.prewarm=false;m.startLifetime=8;m.maxParticles=1;m.startColor=color;var e=ps.emission;e.SetBursts(new[]{new ParticleSystem.Burst(0,1)});
            if(breathe){var a=new GradientAlphaKey[8];for(int i=0;i<8;i++){float u=i/7f;a[i]=new GradientAlphaKey(.92f+.08f*Mathf.Sin(u*Mathf.PI*6),u);}Gradient(ps,new[]{new GradientColorKey(Color.white,0),new GradientColorKey(Color.white,1)},a);}
        }
        static GameObject MakePrefab(bool prop)
        {
            // Materials are shared by the two new prefabs, but never by the previous approved version.
            Func<string,string,int,bool,bool,Material> mat=(name,file,order,add,core)=>AssetDatabase.LoadAssetAtPath<Material>(Root+"/Materials/"+name+".mat")??Material(name,file,order,add,core);
            var root=Emitter(null,prop?FullName:FlameName,null,0,8);var emission=root.emission;emission.enabled=false;
            var main=root.main;main.prewarm=false;main.maxParticles=1;root.GetComponent<ParticleSystemRenderer>().enabled=false;
            Core(Group(root.transform,"01_Fire - one noise-driven realtime particle"),mat("Flame","FlowNoise.png",10,false,true));
            var sparks=Group(root.transform,"02_Sparks and embers - native motion");var sparkMat=mat("Sparks","SparkStreak.png",30,true,false);
            Spark(sparks,sparkMat,false);Spark(sparks,sparkMat,true);Smoke(Group(root.transform,"03_Smoke - native expansion"),mat("Smoke","SmokePuff.png",0,false,false));
            var glows=Group(root.transform,"04_Glow - native additive");var glowMat=mat("Glow","SoftGlow.png",-5,true,false);
            Glow(glows,glowMat,"Fire halo",new Vector2(0,135/PPU),new Vector2(536/PPU,700/PPU),ColorHex("#ff8423",.085f*.65f),true);
            Glow(glows,glowMat,"Bowl halo",new Vector2(0,22/PPU),new Vector2(364/PPU,250/PPU),ColorHex("#ffb443",.14f*.65f),false);
            if(prop)
            {
                Glow(glows,glowMat,"Ground halo",new Vector2(0,-298/PPU),new Vector2(460/PPU,64/PPU),ColorHex("#ff8423",.14f*.65f),false);
                var props=Group(root.transform,"05_Prop - ordinary static sprites");
                foreach(string part in new[]{"Back","Front"}){var go=new GameObject("Prop"+part);go.transform.SetParent(props,false);var sr=go.AddComponent<SpriteRenderer>();
                    sr.sprite=AssetDatabase.LoadAssetAtPath<Sprite>(Root+"/Textures/Prop"+part+".png");sr.sortingOrder=part=="Back"?4:20;sr.sharedMaterial=mat("Prop"+part,"Prop"+part+".png",sr.sortingOrder,false,false);}
            }
            string path=Root+"/Prefabs/"+root.name+".prefab";var prefab=PrefabUtility.SaveAsPrefabAsset(root.gameObject,path);UnityEngine.Object.DestroyImmediate(root.gameObject);return prefab;
        }
    }
}
