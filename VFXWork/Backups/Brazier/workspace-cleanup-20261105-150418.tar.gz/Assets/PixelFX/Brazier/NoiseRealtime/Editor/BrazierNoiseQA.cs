using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;

namespace PixelFX.Brazier.NoiseRealtime.Editor
{
    // Editor-only observation/capture. Never attached to effects, never a playback dependency.
    public static class BrazierNoiseQA
    {
        const string Root=BrazierNoiseSetup.Root,Preview=BrazierNoiseSetup.Preview;
        [Serializable] class StructureReport
        {
            public bool passed,noAttachedScripts,noFlipbook,noAnimator,noVfxLights,staticTexturesOnly;
            public string dataPath,scene,timestamp;public int fullSystems,flameSystems,coreSystems,staticTextureCount;
            public string[] componentTypes,dependencies;
        }
        [Serializable] class LiveReport
        {
            public bool passed,actualPlayMode,motionObserved,smokeRises,smokeGrows,customClockAdvances,emissionZeroStops,emissionRestores;
            public string scene,timestamp,note;public int sparksBefore,sparksOff,sparksRestored,smokeBefore,smokeOff,smokeRestored,coreParticles,capturedFrames;
            public float clockBefore,clockAfter,motionDistance,smokeRise,smokeSizeBefore,smokeSizeAfter;public double elapsedSeconds,captureSeconds;
        }
        static GameObject[] Roots()
        {
            BrazierNoiseSetup.VerifyTarget();if(SceneManager.GetActiveScene().path!=BrazierNoiseSetup.ScenePath)throw new Exception("Open the new noise showcase first.");
            return SceneManager.GetActiveScene().GetRootGameObjects().Where(x=>x.name==BrazierNoiseSetup.FullName||x.name==BrazierNoiseSetup.FlameName).ToArray();
        }
        [MenuItem("Tools/PixelFX/Brazier Noise Realtime/Validate NO Flipbook or Scripts")]
        public static void Validate()
        {
            var roots=Roots();if(roots.Length!=2)throw new Exception("Expected two showcase instances.");var deps=new HashSet<string>();
            foreach(string name in new[]{BrazierNoiseSetup.FullName,BrazierNoiseSetup.FlameName})
            {
                string path=Root+"/Prefabs/"+name+".prefab";var prefab=AssetDatabase.LoadAssetAtPath<GameObject>(path);if(!prefab)throw new Exception("Missing prefab.");
                foreach(var target in new[]{prefab,roots.Single(x=>x.name==name)})
                {
                    var components=target.GetComponentsInChildren<Component>(true);
                    if(components.Any(c=>!c||!(c is Transform||c is ParticleSystem||c is ParticleSystemRenderer||c is SpriteRenderer)))throw new Exception("Unexpected attached/missing component: "+name);
                    var systems=target.GetComponentsInChildren<ParticleSystem>(true);if(systems.Length!=(name==BrazierNoiseSetup.FullName?8:7))throw new Exception("Unexpected native system count.");
                    if(systems.Count(p=>p.name.StartsWith("Core"))!=1)throw new Exception("Expected one real-time noise core.");
                    foreach(var ps in systems)
                    {
                        var sheet=ps.textureSheetAnimation;var r=ps.GetComponent<ParticleSystemRenderer>();
                        if(sheet.enabled||sheet.numTilesX!=1||sheet.numTilesY!=1||ps.lights.enabled||ps.subEmitters.subEmittersCount!=0||ps.main.stopAction==ParticleSystemStopAction.Callback)
                            throw new Exception("Flipbook / Light / hidden callback is forbidden: "+ps.name);
                        if(!r.enabled)continue;
                        if(!r.sharedMaterial||!r.sharedMaterial.mainTexture||ShaderUtil.ShaderHasError(r.sharedMaterial.shader)||!r.sharedMaterial.shader.isSupported
                            ||r.alignment!=ParticleSystemRenderSpace.View||r.allowRoll)throw new Exception("Invalid billboard/shader: "+ps.name);
                        if(ps.name.StartsWith("Core"))
                        {
                            var streams=new List<ParticleSystemVertexStream>();r.GetActiveVertexStreams(streams);
                            if(r.sharedMaterial.shader.name!=BrazierNoiseSetup.FlameShader||!ps.customData.enabled||ps.main.maxParticles!=1||!streams.Contains(ParticleSystemVertexStream.Custom1XYZW))throw new Exception("Core must be a native-clock static-noise shader.");
                        }
                    }
                    if(target.GetComponentsInChildren<SpriteRenderer>(true).Length!=(name==BrazierNoiseSetup.FullName?2:0))throw new Exception("Prop split mismatch.");
                }
                foreach(string d in AssetDatabase.GetDependencies(path,true))
                {
                    deps.Add(d);if(new[]{".cs",".json",".anim",".controller",".gif",".mp4",".playable"}.Contains(Path.GetExtension(d).ToLowerInvariant())
                        ||(d.StartsWith("Assets/")&&!d.StartsWith(Root+"/")))throw new Exception("Unexpected script/movie/old-version dependency: "+d);
                }
            }
            var textures=AssetDatabase.FindAssets("t:Texture2D",new[]{Root+"/Textures"});if(textures.Length!=6)throw new Exception("Expected only six static textures.");
            foreach(string guid in textures)
            {
                string path=AssetDatabase.GUIDToAssetPath(guid);var ti=(TextureImporter)AssetImporter.GetAtPath(path);bool noise=path.EndsWith("FlowNoise.png");
                if(ti.mipmapEnabled||ti.filterMode!=FilterMode.Bilinear||ti.textureCompression!=TextureImporterCompression.Uncompressed||ti.sRGBTexture==noise
                    ||ti.wrapMode!=(noise?TextureWrapMode.Mirror:TextureWrapMode.Clamp))throw new Exception("Texture import contract mismatch: "+path);
            }
            Directory.CreateDirectory(Preview);var full=roots.Single(x=>x.name==BrazierNoiseSetup.FullName);
            File.WriteAllText(Preview+"/Structure.json",JsonUtility.ToJson(new StructureReport{passed=true,noAttachedScripts=true,noFlipbook=true,noAnimator=true,noVfxLights=true,staticTexturesOnly=true,
                dataPath=Application.dataPath,scene=SceneManager.GetActiveScene().path,timestamp=DateTime.Now.ToString("O"),fullSystems=8,flameSystems=7,coreSystems=1,staticTextureCount=6,
                componentTypes=full.GetComponentsInChildren<Component>(true).Select(x=>x.GetType().Name).Distinct().OrderBy(x=>x).ToArray(),dependencies=deps.OrderBy(x=>x).ToArray()},true));
            Debug.Log("[Brazier Noise] PASS structure: prefab + instances, 6 static PNGs, NO runtime scripts/flipbook/Animator/Light/movie.");
        }
        static Camera CaptureCamera()
        {
            var go=new GameObject("TEMP Editor-only noise QA camera"){hideFlags=HideFlags.HideAndDontSave};var c=go.AddComponent<Camera>();c.CopyFrom(Camera.main);c.enabled=false;
            c.GetUniversalAdditionalCameraData().renderPostProcessing=false;return c;
        }
        static void Solo(Camera c,GameObject root)
        {
            c.orthographic=true;c.orthographicSize=5;c.clearFlags=CameraClearFlags.SolidColor;c.backgroundColor=new Color(21/255f,24/255f,32/255f);
            c.transform.SetPositionAndRotation(root.transform.position+new Vector3(0,215f/128,-12),Quaternion.identity);
        }
        static void Render(Camera camera,string name,int width=768,int height=960)
        {
            string path=Preview+"/"+name+".png";Directory.CreateDirectory(Path.GetDirectoryName(path));
            var rt=RenderTexture.GetTemporary(width,height,24,RenderTextureFormat.ARGB32,RenderTextureReadWrite.sRGB);var old=RenderTexture.active;Texture2D texture=null;
            try{camera.aspect=(float)width/height;RenderPipeline.SubmitRenderRequest(camera,new UniversalRenderPipeline.SingleCameraRequest{destination=rt});RenderTexture.active=rt;
                texture=new Texture2D(width,height,TextureFormat.RGBA32,false);texture.ReadPixels(new Rect(0,0,width,height),0,0);texture.Apply();File.WriteAllBytes(path,texture.EncodeToPNG());}
            finally{RenderTexture.active=old;RenderTexture.ReleaseTemporary(rt);if(texture)UnityEngine.Object.DestroyImmediate(texture);}
        }
        static void Simulate(float time)
        {
            if(Application.isPlaying)throw new Exception("Use real live observation in Play Mode, not simulation.");
            // The source analytic loop is already in a steady state at t=0. Warm one exact core
            // cycle before comparison so native smoke is not compared in its cold startup state.
            foreach(var root in Roots()){var ps=root.GetComponent<ParticleSystem>();ps.Simulate(time+BrazierNoiseSetup.CoreLifetime,true,true,false);ps.Pause(true);}
        }
        [MenuItem("Tools/PixelFX/Brazier Noise Realtime/Capture Layers and Views")]
        public static void Capture()
        {
            if(Application.isPlaying)throw new Exception("Capture comparisons in Edit Mode.");Validate();var roots=Roots();var full=roots.Single(x=>x.name==BrazierNoiseSetup.FullName);
            var renderers=roots.SelectMany(x=>x.GetComponentsInChildren<Renderer>(true)).ToArray();var enabled=renderers.Select(r=>r.enabled).ToArray();var c=CaptureCamera();
            try
            {
                Simulate(.8f);Render(c,"Showcase",1280,720);Solo(c,full);
                Action<Transform> only=group=>{for(int i=0;i<renderers.Length;i++)renderers[i].enabled=enabled[i]&&renderers[i].transform.IsChildOf(group);};
                only(full.transform);Render(c,"SourcePhase_0.8",1024,1280);
                c.backgroundColor=new Color(187/255f,183/255f,177/255f);Render(c,"LightBackground");Solo(c,full);
                foreach(string layer in new[]{"01_Fire","02_Sparks","03_Smoke","04_Glow","05_Prop"}){only(full.transform.Cast<Transform>().Single(t=>t.name.StartsWith(layer)));Render(c,layer);}
                // Clone the material for this QA probe: do not mutate the authored material asset.
                var core=full.GetComponentsInChildren<ParticleSystem>().Single(p=>p.name.StartsWith("Core")).GetComponent<ParticleSystemRenderer>();
                var original=core.sharedMaterial;var probe=new Material(original);
                try{only(core.transform);core.sharedMaterial=probe;probe.SetFloat("_Dissolve",1);Render(c,"Dissolve1");probe.SetFloat("_Dissolve",original.GetFloat("_Dissolve"));probe.SetFloat("_Layer",1);Render(c,"NoiseData");}
                finally{core.sharedMaterial=original;UnityEngine.Object.DestroyImmediate(probe);}
                only(full.transform);var center=full.transform.position+new Vector3(0,1.5f,0);
                c.transform.position=center+Quaternion.Euler(30,30,0)*new Vector3(0,0,-12);c.transform.LookAt(center);Render(c,"Oblique30deg");
                Solo(c,full);Simulate(1.8f);Render(c,"SourcePhase_1.8",1024,1280);
            }
            finally{for(int i=0;i<renderers.Length;i++)if(renderers[i])renderers[i].enabled=enabled[i];UnityEngine.Object.DestroyImmediate(c.gameObject);Simulate(.8f);}
        }
        static float Clock(ParticleSystem ps){var data=new List<Vector4>();ps.GetCustomParticleData(data,ParticleSystemCustomData.Custom1);return data.Count>0?data[0].x:-1;}
        static Action stopLive;
        [MenuItem("Tools/PixelFX/Brazier Noise Realtime/Verify ACTUAL Play Mode and Capture")]
        public static void VerifyLivePlayback()
        {
            if(!Application.isPlaying||stopLive!=null)throw new Exception("Enter Play Mode first, with no QA already running.");var roots=Roots();var full=roots.Single(x=>x.name==BrazierNoiseSetup.FullName);var other=roots.Single(x=>x!=full);
            var systems=full.GetComponentsInChildren<ParticleSystem>();var sparks=systems.Single(x=>x.name.StartsWith("Sparks"));var smoke=systems.Single(x=>x.name.StartsWith("Smoke"));var core=systems.Single(x=>x.name.StartsWith("Core"));
            var p=new ParticleSystem.Particle[128];int n=sparks.GetParticles(p);if(n==0)throw new Exception("Wait for native emission startup.");int youngest=Enumerable.Range(0,n).OrderBy(i=>p[i].startLifetime-p[i].remainingLifetime).First();uint sparkSeed=p[youngest].randomSeed;Vector3 sparkPosition=p[youngest].position;
            n=smoke.GetParticles(p);if(n==0)throw new Exception("Wait for native smoke startup.");int oldest=Enumerable.Range(0,n).OrderBy(i=>p[i].startLifetime-p[i].remainingLifetime).First();
            uint smokeSeed=p[oldest].randomSeed;Vector3 smokePosition=p[oldest].position;float smokeSize=p[oldest].GetCurrentSize3D(smoke).magnitude;
            var sparkRate=sparks.emission.rateOverTime;var smokeRate=smoke.emission.rateOverTime;bool active=other.activeSelf;
            bool background=Application.runInBackground;Application.runInBackground=true; // QA environment only, no persistent PlayerSettings change.
            var c=CaptureCamera();Solo(c,full);other.SetActive(false);
            var report=new LiveReport{actualPlayMode=true,sparksBefore=sparks.particleCount,smokeBefore=smoke.particleCount,clockBefore=Clock(core),smokeSizeBefore=smokeSize,
                scene=SceneManager.GetActiveScene().path,timestamp=DateTime.Now.ToString("O"),note="Actual Unity engine playback; Editor callback observes/captures and temporarily toggles native Emission. No Simulate/Emit/SetParticles or shader-clock writes. No subemitters: source has independent smoke births."};
            double started=EditorApplication.timeSinceStartup,stageAt=started,nextCapture=started;int stage=0,frame=0;bool sampled=false;EditorApplication.CallbackFunction tick=null;
            stopLive=()=>{EditorApplication.update-=tick;if(sparks){var e=sparks.emission;e.rateOverTime=sparkRate;}if(smoke){var e=smoke.emission;e.rateOverTime=smokeRate;}if(other)other.SetActive(active);Application.runInBackground=background;if(c)UnityEngine.Object.DestroyImmediate(c.gameObject);stopLive=null;};
            tick=()=>
            {
                try
                {
                    if(!Application.isPlaying||!sparks){stopLive();return;}double now=EditorApplication.timeSinceStartup,elapsed=now-stageAt;
                    if(stage==0)
                    {
                        if(now>=nextCapture&&frame<64){Render(c,"LiveMotion/Frame_"+frame.ToString("000"),512,640);frame++;nextCapture=now+1.0/15;}
                        if(elapsed>.20&&!sampled)
                        {
                            report.clockAfter=Clock(core);report.customClockAdvances=report.clockAfter>=0&&Mathf.Abs(report.clockAfter-report.clockBefore)>.02f;
                            n=sparks.GetParticles(p);for(int i=0;i<n;i++)if(p[i].randomSeed==sparkSeed){report.motionDistance=Vector3.Distance(sparkPosition,p[i].position);report.motionObserved=report.motionDistance>.005f;}
                            n=smoke.GetParticles(p);for(int i=0;i<n;i++)if(p[i].randomSeed==smokeSeed){report.smokeRise=p[i].position.y-smokePosition.y;report.smokeRises=report.smokeRise>.01f;
                                report.smokeSizeAfter=p[i].GetCurrentSize3D(smoke).magnitude;report.smokeGrows=report.smokeSizeAfter>smokeSize;}
                            // Editor callbacks can run before the first native game frame when focus changes.
                            // Keep observing until an engine frame actually advances; never drive the particles.
                            sampled=report.customClockAdvances&&report.motionObserved&&report.smokeRises&&report.smokeGrows;
                        }
                        if(frame<64)return;report.captureSeconds=now-started;var se=sparks.emission;se.rateOverTime=0;var me=smoke.emission;me.rateOverTime=0;stage=1;stageAt=now;
                    }
                    else if(stage==1&&elapsed>3.4)
                    {
                        report.sparksOff=sparks.particleCount;report.smokeOff=smoke.particleCount;report.emissionZeroStops=report.sparksOff==0&&report.smokeOff==0;
                        var se=sparks.emission;se.rateOverTime=sparkRate;var me=smoke.emission;me.rateOverTime=smokeRate;stage=2;stageAt=now;
                    }
                    else if(stage==2&&elapsed>1.3)
                    {
                        report.sparksRestored=sparks.particleCount;report.smokeRestored=smoke.particleCount;report.emissionRestores=report.sparksRestored>0&&report.smokeRestored>0;
                        report.coreParticles=core.particleCount;report.capturedFrames=frame;report.elapsedSeconds=now-started;
                        report.passed=report.motionObserved&&report.smokeRises&&report.smokeGrows&&report.customClockAdvances&&report.emissionZeroStops&&report.emissionRestores&&report.coreParticles==1;
                        stopLive();File.WriteAllText(Preview+"/LivePlayback.json",JsonUtility.ToJson(report,true));Validate();Debug.Log("[Brazier Noise] ACTUAL live playback, smoke rise/growth, sparks, clock, Emission off-expire-restore: "+report.passed);
                    }
                }
                catch(Exception ex){stopLive?.Invoke();Debug.LogException(ex);}
            };
            EditorApplication.update+=tick;Debug.Log("[Brazier Noise] Live observational QA started.");
        }
    }
}
