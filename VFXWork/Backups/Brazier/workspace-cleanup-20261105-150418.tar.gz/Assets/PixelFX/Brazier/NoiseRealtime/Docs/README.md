# Brazier · Noise Realtime

本文资源路径相对于 `NoiseRealtime/` 版本根目录（本文件的上一级）。

作者明确指令“接下来导入到unity中”后创建的独立 Unity 版本。来源为 pixelfx
`Tools/PixelFX/src/hd/noise-brazier.js` version 4 / seed 8，选用当前预览的“旺盛翻卷”参数。
旧 InspectorParticles、HandPaintedRealtime 及作者手调场景没有被覆盖。

## 使用

- `Prefabs/BrazierNoiseRealtime.prefab`：完整静态火盆 + 火焰、火星、余烬、轻烟和光晕。
- `Prefabs/BrazierNoiseFlameRealtime.prefab`：不带火盆，放到现有 3D 模型火口使用。
- `Scenes/BrazierNoiseShowcase.unity`：左侧完整版本，右侧独立火焰版本。

根节点是火口；PPU=128。所有可见粒子采用 View Billboard / Allow Roll Off，
火星采用 Stretched Billboard；火盆是两个普通 SpriteRenderer，并非 3D 模型。
独立版本适合放在已有 3D 火盆上；斜视角下静态火盆仍是平面插画。

## 制作方法：非序列帧

核心火焰只有一个原生粒子，URP Shader 对原灰度图进行多速率采样、纵向拉伸、UV 翻卷、
多峰遮罩、溶解侵蚀和温度色带映射。Custom Data 的 Custom1.x 由原生曲线提供秒数，
不由 Update 或外部控制器写入。没有烘焙火焰贴图。

全版本 8 个 ParticleSystem（含不发射的根入口），独立火焰版 7 个。
无挂载脚本、缺失脚本、Animator、Timeline、Light、视频、图集或 Texture Sheet Animation。
烟雾是独立持续发射，与原稿一致，不添加原稿没有的死亡子发射器。
`Editor/` 中的生成器和检查工具只在编辑器工作，不是预制体运行依赖。

资源只有 6 张独立静态 PNG：原始 FlowNoise 1024²、SmokePuff 256²、SparkStreak 64²、
火盆前后层各 512²、SoftGlow 256²。噪声按线性数据读取、Mirror；其他为 Clamp。
全部 Bilinear、无 mipmap、无压缩、无序列帧。

## 调整位置

| 要调整的表现 | Inspector 位置 |
| --- | --- |
| 火舌密度、纵向拉伸、翻卷、溶解、柔边、热芯、色阶 | `Materials/Flame.mat` 的 Scale / Stretch / Distortion / Dissolve / Softness / Core / Steps |
| 火焰速度 | Flame 材质 Flow；同时将 Core 的 Main Duration、Start Lifetime 改为 `8/Flow`，Custom1.x 曲线乘数改为同值，避免原生时钟重启跳变 |
| 火星数量 | `02_Sparks…/Sparks…` 的 Emission Rate over Time，默认 6/s（基础时钟） |
| 余烬数量 | `02_Sparks…/Embers…` 的 Emission，默认 2/s |
| 火星方向和飞散范围 | Shape Box、Velocity over Lifetime、Noise；Renderer 的 Length Scale 决定细长程度 |
| 烟量 / 浓度 | `03_Smoke…/Smoke…` 的 Emission（默认 3.5/s）/ Color over Lifetime 的 Alpha（峰值 .18） |
| 烟雾扩散和侧向漂移 | Size over Lifetime、Velocity X、Noise |
| 光晕强度 | `04_Glow…` 各粒子的 Start Color Alpha，或 Glow 材质 Tint Alpha |
| 次级层整体速度 | 各次级粒子 Main Simulation Speed，默认 1.45；寿命和发射率仍是可编辑的基础时钟值 |

连续发射粒子已开启 Prewarm。火焰核心按 `8/1.45` 秒循环；光晕用原生颜色曲线呼吸。
改变 Emission 后，已有粒子仍会自然耗尽；不会由脚本立即删粒子。

## 对照与验证

菜单 `Tools > PixelFX > Brazier Noise Realtime` 提供结构检查、分层/斜视角截图和真实 Play Mode 检查。
默认 Build 只创建新版本，已有 prefab 时会拒绝覆盖；手动调参后请保存 Variant。
检查输出在工程外层 `VFXWork/Previews/Brazier/NoiseRealtime/`；PNG/GIF 都只是审稿媒体，不导入运行资源。

源参数、文件 hash、锚点、贴图合同和映射在 `VFXWork/Exports/Brazier/NoiseRealtime/manifest.json`。
原生随机发射、Noise 与参考寿命速度曲线是源解析轨迹的视觉近似；不承诺粒子身份逐个一致。
原始火星的独立高温头部绘制以细长贴图和冷却色彩近似；Unity 线性透明/加法混合与 Canvas
有少量亮度差异。验证区分保存的结构、真实播放和画面对比，不包含移动设备性能保证。

本轮真实 Play Mode 检查通过：1 个核心粒子、Custom1 时钟推进、火星位移、烟雾上升和尺寸增长；
火星数量 9 → Emission 关闭并耗尽后 0 → 恢复后 9，烟雾 10 → 0 → 7。
编辑器检查临时允许后台游戏帧推进，结束后恢复；没有修改 PlayerSettings 或依赖该检查才能播放。
Unity 线性混合下光晕降低了 Alpha，灰烟使用原生颜色工作流校准，避免重复线性化造成过暗。
